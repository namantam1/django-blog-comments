from django.apps import AppConfig


class DjangoBlogCommentConfig(AppConfig):
    name = 'django_blog_comment'
